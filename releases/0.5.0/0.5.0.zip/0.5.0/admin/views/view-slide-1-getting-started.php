<h2 id="modalTitle"><?php _e( 'Welcome to your new site!', BMSO_TEXT_DOMAIN ); ?></h2>
<p class="text-center"><?php _e( 'Let\'s get started on setting it up!', BMSO_TEXT_DOMAIN ); ?></p>
<div class="img-lg-centered">
	<img src="<?php echo $img_dir.'welcome.png'; ?>">
</div>