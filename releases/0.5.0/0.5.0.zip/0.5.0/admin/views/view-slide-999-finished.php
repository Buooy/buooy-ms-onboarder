<h2 id="modalTitle"><?php _e( 'Setup Completed!', BMSO_TEXT_DOMAIN ); ?></h2>
<p class="text-center"><?php _e( 'We are done! You can continue to your new site.', BMSO_TEXT_DOMAIN ); ?></p>
<div class="img-xlg-centered">
	<img src="<?php echo $img_dir.'finished.png'; ?>">
</div>