<?php
// This is the dynamic view
